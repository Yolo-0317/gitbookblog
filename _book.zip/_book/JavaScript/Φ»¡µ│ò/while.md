# while
> while 循环会在指定条件为真时循环执行代码块。

```
while (条件)
{
    需要执行的代码
}
```
> 如果您忘记增加条件中所用变量的值，该循环永远不会结束。这可能导致浏览器崩溃。

## continue break return在while中的作用

- continue 用于跳过循环中的一个迭代。
- break 语句用于跳出循环。
- return 语句会终止函数的执行并返回函数的值。
