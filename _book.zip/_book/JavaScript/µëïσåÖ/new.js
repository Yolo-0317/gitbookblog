/**
 * 构造函数new一个对象实例的过程
 * 1. 创建一个新对象实例；
 * 2. 将构造函数的this指向新对象实例
 * 3. 执行构造函数中的代码，为新对象实例添加属性
 * 4. 返回新对象实例
 */

// Object.create()方法创建一个新对象，使用现有的对象来提供新创建的对象的__proto__。

function simpleNew(fn, ...args) {
  const obj = Object.create(fn.prototype);
  const res = fn.apply(obj, args);
  console.log(res instanceof Object);
  return res instanceof Object ? res : obj;
}

function Person() {
  this.name = "person1";
  return {
    name: "00",
    sayHi: () => {
      console.log(`Hi--1, I am ${this.name}`);
    },
  };
}

Person.prototype.sayHi = function () {
  console.log(`Hi, I am ${this.name}`);
};

const person = simpleNew(Person);

// console.log(person.name)
person.sayHi();
