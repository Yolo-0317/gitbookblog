#### 事件循环 EventLoop

运行机制是，先会执行栈中的内容，栈中的内容执行后执行微任务，微任务清空后再执行宏任务，
先取出一个宏任务，再去执行微任务，然后在取宏任务清微任务这样不停的循环。

代码题：

```JavaScript
function app() {
  setTimeout(() => {
    console.log("1-1");
    Promise.resolve().then(() => {
      console.log("2-1");
    });
  });
  console.log("1-2");
  Promise.resolve().then(() => {
    console.log("1-3");
    setTimeout(() => {
      console.log("3-1");
    });
  });
}
app();
```

结果

```text
1-2
1-3
1-1
2-1
3-1
```

1. 先执行同步
2. 同一层级下(不理解层级，可以先不管，后面会讲)，微任务永远比宏任务先执行
3. 每个宏任务,都单独关联了一个微任务队列

宏任务包括
![宏任务](http://www.yoloworld.site:3000/blogpng/%E5%AE%8F%E4%BB%BB%E5%8A%A1.png)
微任务包括
![微任务](http://www.yoloworld.site:3000/blogpng/%E5%BE%AE%E4%BB%BB%E5%8A%A1.png)
