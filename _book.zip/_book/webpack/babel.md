> Babel 是一个 JavaScript 编译器。他把最新版的javascript编译成当下可以执行的版本，

> 简言之，利用babel就可以让我们在当前的项目中随意的使用这些新最新的es语法。

##### Babel的运行原理

###### 解析

解析步骤接收代码并输出 AST。 这个步骤分为两个阶段：词法分析（Lexical Analysis） 和 语法分析（Syntactic Analysis）。

1. 词法分析
2. 语法分析
将词法分析的结果转换成AST形式

###### 转换
