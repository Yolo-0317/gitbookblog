执行 node index.js，生成YoloBlog.md

VsCode打开YoloBlog.md，用Markdown Preview Enhanced打开文件，右侧编辑态光标移动到最上面

cmd+shift+p
执行Markdown Preview Enhanced: Create Toc
然后保存编辑态文件
然后在Markdown Preview Enhanced中右键点击 PDF（prince）导出pdf文件